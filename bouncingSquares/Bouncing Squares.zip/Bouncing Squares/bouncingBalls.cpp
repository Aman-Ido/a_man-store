/* 
making bouncing balls
*/
#include <iostream>
#include <stdio.h>
#include <SDL2/SDL.h>
#include <ctime>
#include <SDL2/SDL_mixer.h>

#define SW 640
#define SH 480

// related to the program
SDL_Window* window = NULL;
SDL_Renderer* render = NULL;

Mix_Chunk* mainSound = NULL;
// definitions
#include "./bouncingBallsFunction.cpp"

#include "./bouncingBallsClass.cpp"

// making a ball object
Balls arr [15];
int numberOfBalls = 15;


// functions
void init() {
	SDL_Init (SDL_INIT_VIDEO | SDL_INIT_AUDIO);
	window = SDL_CreateWindow ("Bouncing Balls", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, SW, SH, SDL_WINDOW_SHOWN);
	if (window == NULL) {
		printf("%s\n", SDL_GetError());
	}
	else {
		render = SDL_CreateRenderer (window, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
		if (render == NULL) {
			printf("%s\n", SDL_GetError());
		}
		else {
			// initalize other things
			// SDL mixer
			if (!(Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 2048))) {
				std::cout << "Could not initalize SDL mixer :: " << Mix_GetError () << std::endl;
			}
		}
	}
}

void eventProgram () {
	SDL_Event e;
	bool quit = false;
	
	for (int i = 0; i < numberOfBalls; i++) {
		arr[i].startBalls (i + 1);
	}
	
	for (int i = 0; i < numberOfBalls; i++) {
		arr[i].moveBalls ();
	}
	while (!quit) {
		while (SDL_PollEvent (&e)) {
			if (e.type == SDL_QUIT) {
				quit = true;
			}
			// code here
			if (e.type == SDL_KEYDOWN && e.key.keysym.sym == SDLK_RETURN) {
				quit = true;
			}
		}
		// code here
		SDL_SetRenderDrawColor (render, 0xff, 0xff, 0xff, 0xff);
		SDL_RenderClear (render);
		
		// drawing the balls
		for (int i = 0; i < numberOfBalls; i++) {
			arr[i].collisionBalls();
			// rendering the balls
			arr[i].renderBalls ();
			
			
			// printf("the random Value is %d\n", arr[0].randomDirection);
		}
		
		// updating the window
		SDL_RenderPresent (render);
	}
}


// function exitProgram
void exitProgram () {
	// code here
	Mix_FreeChunk (mainSound);
	Mix_CloseAudio();
	Mix_Quit();
	
	SDL_DestroyRenderer (render);
	SDL_DestroyWindow (window);
	SDL_Quit();
}

// function_main
int main (int argc, char** argv) {
	init();
	
	mainSound = Mix_LoadWAV ("./PickupCoin.wav");
	if (mainSound == NULL) {
		std::cout << "Could not load sound :: " << Mix_GetError () << std::endl;
		return -1;
	}
	
	eventProgram ();
	
	exitProgram ();
	
	
	return 0;
}
