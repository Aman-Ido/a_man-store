int getRandomNumber (int limit, int change) {
	srand (time(NULL) * change);
	return rand() % limit;
}

std::string directionArray [] = {
	"north", "south", "east", "west"
};