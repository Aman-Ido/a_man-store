// class balls
class Balls {
	public:
		const int totalColor = 255;
		int randomDirection = 0;
		const int motionValue = 3;		

		SDL_Color mColor;
		
		Balls ();
		
		// initalize
		void startBalls (int i);
		
		// renderer
		void renderBalls ();
		
		// moving balls
		void moveBalls ();
		
		// collision Balls
		void collisionBalls ();
		
		// get mRect
		SDL_Rect getRect ();
		
		// get velocityValue
		SDL_Point getVelocityValue ();
	
	private:
		SDL_Rect mRect;
		SDL_Point velocityValue;
};

Balls::Balls () {


	velocityValue.x = motionValue;
	velocityValue.y = motionValue;
}

void Balls::startBalls (int i) {
	mRect.x = getRandomNumber (SW, i);
	mRect.y = getRandomNumber (SH, i);
	mRect.w = getRandomNumber (50, i);
	mRect.h = mRect.w;	

	randomDirection = getRandomNumber (4, i);

	mColor.r = getRandomNumber (totalColor, i);
	mColor.g = getRandomNumber (totalColor, i + 1);
	mColor.b = getRandomNumber (totalColor, i + 2);
	mColor.a = getRandomNumber (totalColor, i + 3);
	
}

SDL_Rect Balls::getRect () {
	return mRect;
}

void Balls::renderBalls () {
	SDL_SetRenderDrawColor (render, mColor.r, mColor.g, mColor.b, mColor.a);
	SDL_RenderFillRect (render, &mRect);
}

void Balls::moveBalls () {
	switch (randomDirection) {
		/* 
			0 = up;
			1 = down;
			2 = left;
			3 = right;
		*/
		case 0:
			velocityValue.y -= motionValue;
			break;
		case 1:
			velocityValue.y += motionValue;
			break;
		case 3:
			velocityValue.x += motionValue; // going right
			break;
		case 2:
			velocityValue.x -= motionValue; // going left
			break;
		default:
			printf("The random value is %d\n", randomDirection);
			break;
	}
	printf("The random value is %d\n", randomDirection);
}

void Balls::collisionBalls () {
	// moving the ball to the left or the right
	mRect.x += velocityValue.x;
	
	// checking if the ball is in 0 px
	if (mRect.x < 0) {
		velocityValue.x += motionValue;
		Mix_PlayChannel (-1, mainSound, 0);
		// mRect.w += 2;
	}
	if (mRect.x + mRect.w > SW) {
		velocityValue.x -= motionValue;
		Mix_PlayChannel (-1, mainSound, 0);
		// mRect.w += 2;
	}
	
	mRect.y += velocityValue.y;
	
	// checking for collision in y-axis
	if (mRect.y < 0) {
		velocityValue.y += motionValue;
		Mix_PlayChannel (-1, mainSound, 0);
		// mRect.w += 2;
	}
	if (mRect.y + mRect.h > SH ){
		velocityValue.y -= motionValue;
		Mix_PlayChannel (-1, mainSound, 0);
		// mRect.w += 2;
	}
}

SDL_Point Balls::getVelocityValue () {
	return velocityValue;
}